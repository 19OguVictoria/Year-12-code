# a file named "quiz" will be opened with the reading mode
quiz = open('extended programming task/hard quizzes.txt', 'r')

# This prints every line in the file one by one
for each in quiz:
    print(each)