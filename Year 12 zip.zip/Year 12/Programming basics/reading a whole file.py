file = open("people.txt", "r")
contents = file.read()
print(contents)
file.close