from character import Character
Id = Character("Id", "A smelly zombie")
Id.describe()