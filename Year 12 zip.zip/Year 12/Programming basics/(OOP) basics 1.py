n = 1
while n > 0:
    n = n + 1
    print(n)