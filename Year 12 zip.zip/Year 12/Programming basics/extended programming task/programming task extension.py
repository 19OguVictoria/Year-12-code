
quizquestions = open(quiz,w)
