def tell(intro, punchline):
    print("knock knock")
    print("whos there")
    print(intro)
    print(intro + " who")
    print(punchline)

tell("atch", "sounds like you've got a cold")

myJoke = Joke("Atch", "sounds like you've got a cold")
myJoke.tell()